extends Node3D
# Zero-G Station - a Heavenly Bodies inspired prototype.
# Left stick = left arm, right stick = right arm.
# Hold L / R to grab walls or the crate, then pull the stick toward you
# to drag your body. Deliver the crate to the green zone.
# Desktop test keys: WASD / arrows = arms, Q / E = grab, R = reset.

const TouchWidget = preload("res://touch_widget.gd")

# ---------------- tuning (play with these!) ----------------
const REACH := 1.5          # how far a stick pushes the hand
const HAND_K := 70.0        # hand spring strength
const HAND_C := 9.0         # hand damping
const MAX_FORCE := 45.0     # max force an arm can apply
const REACTION := 0.6       # how much of the arm force pushes your body
const MAX_ARM := 2.3        # arm leash length
const LEASH_K := 140.0      # leash stiffness
const SHOULDERS = [Vector3(-0.4, 0.3, 0.0), Vector3(0.4, 0.3, 0.0)]
const REST = [Vector3(-0.5, -0.6, 0.0), Vector3(0.5, -0.6, 0.0)]

# crate start, target, astronaut start, extra walls [position, size]
const LEVELS = [
    {"crate": Vector3(-5, -3.5, 0), "target": Vector3(6, 2.5, 0), "start": Vector3(-3, 0, 0),
     "walls": []},
    {"crate": Vector3(-6, 2.5, 0), "target": Vector3(6, -3.5, 0), "start": Vector3(-3, 0, 0),
     "walls": [[Vector3(0, -2.2, 0), Vector3(0.6, 5.6, 1.0)]]},
    {"crate": Vector3(1, -3.5, 0), "target": Vector3(-7, 3.5, 0), "start": Vector3(3, 0, 0),
     "walls": [[Vector3(-4.5, 0.5, 0), Vector3(5.0, 0.6, 1.0)]]},
]

var body: RigidBody3D
var crate: RigidBody3D
var hands: Array = []
var grab_areas: Array = []
var grab_joints: Array = [null, null]
var arm_meshes: Array = []
var obstacles: Node3D
var target_mesh: MeshInstance3D
var target_pos: Vector3 = Vector3.ZERO
var left_ui
var right_ui
var grab_l
var grab_r
var reset_ui
var label: Label
var level: int = 0
var hold: float = 0.0
var won: bool = false
var win_timer: float = 0.0
var reset_prev: bool = false


func _ready() -> void:
    _build_environment()
    _build_room()
    _build_astronaut()
    _build_crate()
    _build_ui()
    _load_level(0)


# ---------------------------------------------------------------- helpers
func _mat(c: Color, emit: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    if c.a < 1.0:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    if emit > 0.0:
        m.emission_enabled = true
        m.emission = Color(c.r, c.g, c.b)
        m.emission_energy_multiplier = emit
    return m


func _pm(bounce: float = 0.15, friction: float = 0.6) -> PhysicsMaterial:
    var p := PhysicsMaterial.new()
    p.bounce = bounce
    p.friction = friction
    return p


func _static_box(parent: Node, pos: Vector3, sz: Vector3, color: Color) -> StaticBody3D:
    var sb := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = sz
    cs.shape = sh
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = sz
    bm.material = _mat(color)
    mi.mesh = bm
    sb.add_child(cs)
    sb.add_child(mi)
    sb.physics_material_override = _pm(0.2, 0.5)
    sb.position = pos
    parent.add_child(sb)
    return sb


func _setup_body(rb: RigidBody3D, mass: float, ldamp: float, adamp: float) -> void:
    rb.mass = mass
    rb.gravity_scale = 0.0
    rb.linear_damp = ldamp
    rb.angular_damp = adamp
    rb.can_sleep = false
    rb.axis_lock_linear_z = true
    rb.axis_lock_angular_x = true
    rb.axis_lock_angular_y = true


# ---------------------------------------------------------------- world
func _build_environment() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.02, 0.02, 0.06)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.75, 0.8, 0.95)
    env.ambient_light_energy = 0.6
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-35, 25, 0)
    sun.light_energy = 1.0
    add_child(sun)

    var cam := Camera3D.new()
    cam.position = Vector3(0, 0, 12.5)
    cam.fov = 50.0
    add_child(cam)
    cam.current = true


func _build_room() -> void:
    var room := Node3D.new()
    add_child(room)
    var wc := Color(0.35, 0.4, 0.5)
    _static_box(room, Vector3(0, -5.5, 0), Vector3(21, 1, 1.6), wc)
    _static_box(room, Vector3(0, 5.5, 0), Vector3(21, 1, 1.6), wc)
    _static_box(room, Vector3(-9.5, 0, 0), Vector3(1, 12, 1.6), wc)
    _static_box(room, Vector3(9.5, 0, 0), Vector3(1, 12, 1.6), wc)

    var back := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(20, 11, 0.2)
    bm.material = _mat(Color(0.08, 0.1, 0.18))
    back.mesh = bm
    back.position = Vector3(0, 0, -0.9)
    room.add_child(back)

    var hc := Color(1.0, 0.8, 0.1)
    for x in [-6.0, -2.0, 2.0, 6.0]:
        _static_box(room, Vector3(x, -4.75, 0), Vector3(1.2, 0.3, 0.5), hc)
        _static_box(room, Vector3(x, 4.75, 0), Vector3(1.2, 0.3, 0.5), hc)
    for y in [-2.0, 2.0]:
        _static_box(room, Vector3(-8.75, y, 0), Vector3(0.3, 1.2, 0.5), hc)
        _static_box(room, Vector3(8.75, y, 0), Vector3(0.3, 1.2, 0.5), hc)

    obstacles = Node3D.new()
    add_child(obstacles)

    target_mesh = MeshInstance3D.new()
    var tm := BoxMesh.new()
    tm.size = Vector3(1.6, 1.6, 0.1)
    tm.material = _mat(Color(0.1, 1.0, 0.4, 0.35), 1.2)
    target_mesh.mesh = tm
    add_child(target_mesh)


func _build_astronaut() -> void:
    body = RigidBody3D.new()
    _setup_body(body, 6.0, 0.4, 2.5)
    body.physics_material_override = _pm(0.1, 0.4)

    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.3
    cs.shape = cap
    body.add_child(cs)

    var torso := MeshInstance3D.new()
    var cm := CapsuleMesh.new()
    cm.radius = 0.4
    cm.height = 1.3
    cm.material = _mat(Color(0.95, 0.95, 0.97))
    torso.mesh = cm
    body.add_child(torso)

    var visor := MeshInstance3D.new()
    var vm := SphereMesh.new()
    vm.radius = 0.28
    vm.height = 0.56
    vm.material = _mat(Color(0.15, 0.3, 0.7), 0.6)
    visor.mesh = vm
    visor.position = Vector3(0, 0.3, 0.25)
    body.add_child(visor)
    add_child(body)

    for i in 2:
        var h := RigidBody3D.new()
        _setup_body(h, 0.4, 0.2, 5.0)
        h.physics_material_override = _pm(0.1, 0.8)
        var hcs := CollisionShape3D.new()
        var hs := SphereShape3D.new()
        hs.radius = 0.22
        hcs.shape = hs
        h.add_child(hcs)
        var hm := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 0.22
        sm.height = 0.44
        sm.material = _mat(Color(1.0, 0.6, 0.15))
        hm.mesh = sm
        h.add_child(hm)

        var area := Area3D.new()
        var acs := CollisionShape3D.new()
        var ash := SphereShape3D.new()
        ash.radius = 0.45
        acs.shape = ash
        area.add_child(acs)
        h.add_child(area)

        h.position = body.position + SHOULDERS[i] + REST[i]
        add_child(h)
        h.add_collision_exception_with(body)
        body.add_collision_exception_with(h)
        hands.append(h)
        grab_areas.append(area)

        var arm := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = 0.07
        cyl.bottom_radius = 0.07
        cyl.height = 1.0
        cyl.radial_segments = 8
        cyl.material = _mat(Color(0.9, 0.9, 0.95))
        arm.mesh = cyl
        add_child(arm)
        arm_meshes.append(arm)

    hands[0].add_collision_exception_with(hands[1])
    hands[1].add_collision_exception_with(hands[0])


func _build_crate() -> void:
    crate = RigidBody3D.new()
    _setup_body(crate, 2.5, 0.3, 1.0)
    crate.physics_material_override = _pm(0.2, 0.5)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(1, 1, 1)
    cs.shape = sh
    crate.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(1, 1, 1)
    bm.material = _mat(Color(0.9, 0.45, 0.15))
    mi.mesh = bm
    crate.add_child(mi)
    add_child(crate)


# ---------------------------------------------------------------- UI
func _widget(layer: Node, stick: bool, cap: String, preset: int, rect: Rect2, fsize: int = 30):
    var w = TouchWidget.new()
    w.is_stick = stick
    w.caption = cap
    w.font_size = fsize
    layer.add_child(w)
    w.set_anchors_preset(preset)
    w.offset_left = rect.position.x
    w.offset_top = rect.position.y
    w.offset_right = rect.position.x + rect.size.x
    w.offset_bottom = rect.position.y + rect.size.y
    return w


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    left_ui = _widget(layer, true, "", Control.PRESET_BOTTOM_LEFT, Rect2(40, -270, 230, 230))
    right_ui = _widget(layer, true, "", Control.PRESET_BOTTOM_RIGHT, Rect2(-270, -270, 230, 230))
    grab_l = _widget(layer, false, "L", Control.PRESET_TOP_LEFT, Rect2(40, 30, 150, 150), 44)
    grab_r = _widget(layer, false, "R", Control.PRESET_TOP_RIGHT, Rect2(-190, 30, 150, 150), 44)
    reset_ui = _widget(layer, false, "RESET", Control.PRESET_CENTER_TOP, Rect2(-50, 20, 100, 100), 20)

    label = Label.new()
    layer.add_child(label)
    label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    label.offset_left = -400
    label.offset_right = 400
    label.offset_top = 125
    label.offset_bottom = 200
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 24)


# ---------------------------------------------------------------- levels
func _release_grabs() -> void:
    for i in 2:
        if grab_joints[i] != null:
            grab_joints[i].queue_free()
            grab_joints[i] = null


func _load_level(n: int) -> void:
    level = n % LEVELS.size()
    var L = LEVELS[level]
    _release_grabs()
    for c in obstacles.get_children():
        obstacles.remove_child(c)
        c.queue_free()
    for w in L["walls"]:
        _static_box(obstacles, w[0], w[1], Color(0.6, 0.35, 0.4))

    crate.global_transform = Transform3D(Basis(), L["crate"])
    crate.linear_velocity = Vector3.ZERO
    crate.angular_velocity = Vector3.ZERO

    var start: Vector3 = L["start"]
    body.global_transform = Transform3D(Basis(), start)
    body.linear_velocity = Vector3.ZERO
    body.angular_velocity = Vector3.ZERO
    for i in 2:
        var h: RigidBody3D = hands[i]
        h.global_transform = Transform3D(Basis(), start + SHOULDERS[i] + REST[i])
        h.linear_velocity = Vector3.ZERO
        h.angular_velocity = Vector3.ZERO

    target_pos = L["target"]
    target_mesh.position = Vector3(target_pos.x, target_pos.y, -0.7)
    hold = 0.0
    won = false
    label.text = "Level %d/%d - move the crate to the green zone\nHold L / R to grab, then pull the stick toward you" % [level + 1, LEVELS.size()]


# ---------------------------------------------------------------- input
func _kb(l: int, r: int, u: int, d: int) -> Vector2:
    return Vector2(
        int(Input.is_key_pressed(r)) - int(Input.is_key_pressed(l)),
        int(Input.is_key_pressed(u)) - int(Input.is_key_pressed(d)))


func _stick(i: int) -> Vector2:
    var ui = left_ui if i == 0 else right_ui
    var v := Vector2(ui.value.x, -ui.value.y)
    if i == 0:
        v += _kb(KEY_A, KEY_D, KEY_W, KEY_S)
    else:
        v += _kb(KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN)
    return v.limit_length(1.0)


func _grab(i: int) -> bool:
    var ui = grab_l if i == 0 else grab_r
    var key: int = KEY_Q if i == 0 else KEY_E
    return bool(ui.pressed) or Input.is_key_pressed(key)


# ---------------------------------------------------------------- physics
func _physics_process(delta: float) -> void:
    for i in 2:
        _drive_hand(i, _stick(i))
        _update_grab(i, _grab(i))

    var reset_now: bool = bool(reset_ui.pressed) or Input.is_key_pressed(KEY_R)
    if reset_now and not reset_prev:
        _load_level(level)
    reset_prev = reset_now

    _check_goal(delta)


func _drive_hand(i: int, dir: Vector2) -> void:
    var hand: RigidBody3D = hands[i]
    var shoulder: Vector3 = body.to_global(SHOULDERS[i])
    var off: Vector3 = REST[i]
    if dir.length() > 0.12:
        off = Vector3(dir.x, dir.y, 0.0) * REACH
    var target: Vector3 = shoulder + off

    var hp: Vector3 = hand.global_position
    var f: Vector3 = (target - hp) * HAND_K - hand.linear_velocity * HAND_C
    f.z = 0.0
    f = f.limit_length(MAX_FORCE)
    hand.apply_central_force(f)
    body.apply_central_force(-f * REACTION)

    var d: Vector3 = hp - shoulder
    var dl: float = d.length()
    if dl > MAX_ARM:
        var pull: Vector3 = d / dl * (dl - MAX_ARM) * LEASH_K
        pull.z = 0.0
        hand.apply_central_force(-pull)
        body.apply_central_force(pull)


func _update_grab(i: int, want: bool) -> void:
    if want and grab_joints[i] == null:
        var hand: RigidBody3D = hands[i]
        for b in grab_areas[i].get_overlapping_bodies():
            if b == hand or b == body or b == hands[1 - i]:
                continue
            var j := PinJoint3D.new()
            add_child(j)
            j.global_position = hand.global_position
            j.node_a = j.get_path_to(hand)
            j.node_b = j.get_path_to(b)
            grab_joints[i] = j
            break
    elif not want and grab_joints[i] != null:
        grab_joints[i].queue_free()
        grab_joints[i] = null


func _check_goal(delta: float) -> void:
    if won:
        win_timer -= delta
        if win_timer <= 0.0:
            _load_level(level + 1)
        return
    var near: bool = crate.global_position.distance_to(target_pos) < 0.7 \
            and crate.linear_velocity.length() < 0.8
    if near:
        hold += delta
    else:
        hold = 0.0
    if hold > 1.0:
        won = true
        win_timer = 2.5
        label.text = "Level complete!"


# ---------------------------------------------------------------- visuals
func _process(_delta: float) -> void:
    for i in 2:
        _arm_visual(arm_meshes[i], body.to_global(SHOULDERS[i]), hands[i].global_position)


func _arm_visual(m: MeshInstance3D, a: Vector3, b: Vector3) -> void:
    var d: Vector3 = b - a
    var len: float = d.length()
    if len < 0.01:
        m.visible = false
        return
    m.visible = true
    var up: Vector3 = d / len
    var ref: Vector3 = Vector3.BACK
    if absf(up.dot(Vector3.BACK)) > 0.99:
        ref = Vector3.RIGHT
    var xa: Vector3 = up.cross(ref).normalized()
    var za: Vector3 = xa.cross(up).normalized()
    m.global_transform = Transform3D(Basis(xa, up * len, za), (a + b) * 0.5)
