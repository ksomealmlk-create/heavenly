extends Control
# Virtual joystick or button. Handles raw multi-touch so both thumbs work at once.

@export var is_stick: bool = true
@export var caption: String = ""
@export var font_size: int = 30

var touch_index: int = -1
var value: Vector2 = Vector2.ZERO
var pressed: bool = false


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if touch_index == -1 and get_global_rect().has_point(event.position):
                touch_index = event.index
                pressed = true
                _update_value(event.position)
        elif event.index == touch_index:
            touch_index = -1
            pressed = false
            value = Vector2.ZERO
            queue_redraw()
    elif event is InputEventScreenDrag:
        if event.index == touch_index:
            _update_value(event.position)


func _update_value(p: Vector2) -> void:
    if is_stick:
        var r: float = min(size.x, size.y) * 0.5
        var c: Vector2 = get_global_rect().get_center()
        value = ((p - c) / r).limit_length(1.0)
    queue_redraw()


func _draw() -> void:
    var r: float = min(size.x, size.y) * 0.5
    var c: Vector2 = size * 0.5
    var fill := Color(1, 1, 1, 0.10)
    if pressed and not is_stick:
        fill = Color(1.0, 0.7, 0.2, 0.55)
    draw_circle(c, r, fill)
    draw_arc(c, r - 2.0, 0.0, TAU, 48, Color(1, 1, 1, 0.55), 3.0)
    if is_stick:
        draw_circle(c + value * r * 0.65, r * 0.33, Color(1, 1, 1, 0.55))
    if caption != "":
        var font: Font = ThemeDB.fallback_font
        draw_string(font, Vector2(0, c.y + font_size * 0.35), caption,
                HORIZONTAL_ALIGNMENT_CENTER, size.x, font_size, Color(1, 1, 1, 0.9))
